# _Calculadora de média - Projeto

A Pen created on CodePen.io. Original URL: [https://codepen.io/samuca__/pen/OJwoEWz](https://codepen.io/samuca__/pen/OJwoEWz).

